# PoliPunte — prototip demonstrativ

Prototip realizat pentru AI-Powered Business Challenge 2026. Nu este afiliat oficial cu Fundația HIPOLITECH sau cu UPB. Nu există donații, plăți sau date reale.

## Cum îl deschizi
Dublu-click pe `index.html`. Nu are nevoie de instalare, internet sau server.

## Cum testezi în 5 pași
1. Începe → „Încarcă exemplu valid” → „Generează brief-ul”: 0,80% · 0,01% · 4,00% · 5,00% și „7/7 reguli respectate”.
2. În Claims Guard apasă „Încearcă un exemplu”: se marchează „cumperi”, „o cameră”, „garantăm”, „deductibilitate”.
3. „Încarcă exemplu invalid”: erori pe câmpuri, fără brief.
4. „Copiază linkul testului” repetă exact același test.
5. Deschide `index.html?selftest=1` pentru testele automate.

## Publicare pe Vercel (static)
Pune `index.html` într-un folder gol și încarcă-l. Fără framework, fără build. Dezactivează orice protecție de deployment: adresa trebuie să fie publică.

## Implementat
Intro cu brief-exemplu real, fapte oficiale, formular cu validări, brief de o pagină, matrice de roluri, lupa de scară, registru (doar pasul 1), Claims Guard (7 reguli + verificator de text), stare în URL, autotest, print A4.

## Nu este implementat
Plăți, login, backend, AI la rulare, mod întunecat, animații, ilustrații generate (versiunea aceasta folosește doar SVG inline).
